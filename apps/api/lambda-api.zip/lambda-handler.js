const serverlessExpress = require('@codegenie/serverless-express');

// Import your existing server
const express = require('express');
const cors = require('cors');
const { Client } = require('pg');

const app = express();

// Initialize PostgreSQL client - this will work perfectly in AWS Lambda
const client = new Client({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:Myashwanth@14@db.dinerkhhhoibcrznysen.supabase.co:5432/postgres",
  ssl: {
    rejectUnauthorized: false
  },
  connectionTimeoutMillis: 10000,
  query_timeout: 10000
});

let dbConnected = false;

// Connect to database
async function connectToDatabase() {
  if (!dbConnected) {
    try {
      await client.connect();
      console.log('✅ Connected to PostgreSQL database');
      dbConnected = true;
    } catch (err) {
      console.error('❌ Database connection error:', err.message);
      dbConnected = false;
    }
  }
}

// Middleware
app.use(cors());
app.use(express.json());

// Environment variables (with fallbacks)
const AWS_LAMBDA_URL = 'https://q0qr0uqja7.execute-api.us-east-1.amazonaws.com/dev';
const AZURE_FUNCTIONS_URL = 'https://codecapsule-api.azurewebsites.net/api';

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: 'lambda',
    database: dbConnected ? 'connected' : 'disconnected',
    databaseUrl: process.env.DATABASE_URL ? 'set' : 'not-set'
  });
});

// My Capsules endpoint - this is the key one that needs real database data
app.get('/api/my-capsules', async (req, res) => {
  console.log('📦 Fetching user capsules...');
  
  // Try to connect to database
  await connectToDatabase();
  
  if (!dbConnected) {
    console.log('⚠️ Database not connected, returning fallback data');
    return res.json({
      success: true,
      capsules: [{
        id: 'lambda-db-test',
        title: '🚀 Lambda Database Test',
        language: 'javascript',
        code: 'console.log("Lambda can connect to Supabase!");',
        description: 'Testing database connection from AWS Lambda',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        isPublic: true,
        tags: ['lambda', 'database-test'],
        author: 'AWS Lambda',
        likes: 0,
        views: 0
      }]
    });
  }

  try {
    // Query for real capsules from Supabase
    const result = await client.query(`
      SELECT 
        id,
        title,
        description,
        type,
        language,
        difficulty,
        tags,
        "isPublished",
        "createdAt",
        "creatorId",
        content
      FROM capsules 
      ORDER BY "createdAt" DESC
    `);

    console.log(`✅ Found ${result.rows.length} capsules in database`);

    // Transform database results to match frontend expectations
    const transformedCapsules = result.rows.map(capsule => {
      let code = '';
      let parsedContent = null;
      
      // Parse the content JSON if it exists
      if (capsule.content) {
        try {
          if (typeof capsule.content === 'string') {
            parsedContent = JSON.parse(capsule.content);
          } else {
            parsedContent = capsule.content;
          }
          
          // Extract code from various possible structures
          if (parsedContent?.primary?.code) {
            code = parsedContent.primary.code;
          } else if (parsedContent?.code) {
            code = parsedContent.code;
          } else if (typeof parsedContent === 'string') {
            code = parsedContent;
          }
        } catch (e) {
          console.log('Failed to parse content JSON:', e.message);
          code = capsule.content?.toString() || '';
        }
      }

      return {
        id: capsule.id,
        title: capsule.title || 'Untitled Capsule',
        description: capsule.description || 'No description',
        language: capsule.language || 'javascript',
        code: code,
        type: capsule.type || 'code',
        difficulty: capsule.difficulty || 'beginner',
        tags: capsule.tags || [],
        createdAt: capsule.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: capsule.createdAt?.toISOString() || new Date().toISOString(),
        isPublic: capsule.isPublished || false,
        author: 'Default User',
        likes: 0,
        views: 0
      };
    });

    res.json({
      success: true,
      capsules: transformedCapsules,
      count: transformedCapsules.length,
      message: `Retrieved ${transformedCapsules.length} capsules from Supabase database`
    });

  } catch (error) {
    console.error('❌ Database query error:', error.message);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch capsules from database',
      details: error.message
    });
  }
});

// Proxy other endpoints to existing services
app.post('/api/generate', async (req, res) => {
  try {
    const response = await fetch(`${AZURE_FUNCTIONS_URL}/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Generation service error', details: error.message });
  }
});

app.post('/api/execute', async (req, res) => {
  try {
    const { language } = req.body;
    const response = await fetch(`${AWS_LAMBDA_URL}/execute/${language.toLowerCase()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Execution service error', details: error.message });
  }
});

// Create the serverless handler
const handler = serverlessExpress({ app });

module.exports = { handler };