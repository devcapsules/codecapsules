import { app, HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';

// Import your existing API routes
import { generateContent } from './routes/generate';
import { validateCode } from './routes/validate';

// Azure Function for AI Generation
export async function generateHandler(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    try {
        const body = await request.json() as any;
        const result = await generateContent(body);
        
        return {
            status: 200,
            jsonBody: result,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        };
    } catch (error: any) {
        context.error('Generate function error:', error);
        return {
            status: 500,
            jsonBody: { error: error.message }
        };
    }
}

// Azure Function for Code Validation
export async function validateHandler(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    try {
        const body = await request.json() as any;
        const result = await validateCode(body);
        
        return {
            status: 200,
            jsonBody: result,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        };
    } catch (error: any) {
        context.error('Validate function error:', error);
        return {
            status: 500,
            jsonBody: { error: error.message }
        };
    }
}

// Health check function
export async function healthHandler(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    return {
        status: 200,
        jsonBody: {
            status: 'healthy',
            service: 'codecapsule-ai-engine',
            version: '1.0.0',
            timestamp: new Date().toISOString()
        }
    };
}

// Register Azure Functions
app.http('generate', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: generateHandler
});

app.http('validate', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: validateHandler
});

app.http('health', {
    methods: ['GET'],
    authLevel: 'anonymous',
    handler: healthHandler
});